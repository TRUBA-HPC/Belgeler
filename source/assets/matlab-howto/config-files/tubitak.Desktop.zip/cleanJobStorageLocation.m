function cleanJobStorageLocation(cluster)
% Deletes all content from both the local and remote job storage locations.

% Copyright 2014-2026 The MathWorks, Inc.

narginchk(1, 1)

if isa(cluster, 'parallel.cluster.Generic')==false
    error('Must supply cluster object.')
end

% Store the current filename for the errors, warnings and
% dctSchedulerMessages.
currFilename = mfilename;

% Delete local job storage location.
jsl = cluster.JobStorageLocation;
if exist(jsl, 'dir')==7
    [success, emsg, eid] = rmdir(jsl, 's');
    if success==false
        error(eid, emsg)
    end
end

% Create local job storage location.
[success, emsg, eid] = mkdir(jsl);
if success==false
    error(eid, emsg)
end

% Get Cluster Host and Remote Job Storage Location.
FAILED = false;
try
    % Don't bother checking if the fields exist.  If they don't, we'll
    % return early anyway.
    clusterHost = cluster.AdditionalProperties.ClusterHost;
    remoteJobStorageLocation = cluster.AdditionalProperties.RemoteJobStorageLocation;
catch
    FAILED = true;
end
if FAILED==true || isempty(clusterHost) || isempty(remoteJobStorageLocation)
    % If either of these are empty, we (a) can't connect to the cluster
    % (must be running "shared") or (b) there's nothing to cleanup
    % (directory is empty).  Return early.
    return
end

% Get remote connection in order to delete remote files.
% The plugin scripts are not on the path.  Need to change directories to it
% first. 
odir = cd(fullfile(cluster.PluginScriptsLocation, "private"));
% Change back to the old directory on cleanup.
x = onCleanup(@()cd(odir));
remoteConnection = getRemoteConnection(cluster);

% Delete old remote job storage location.
try
    commandToRun = sprintf('rm -rf %s', remoteJobStorageLocation);
    % Execute the command on the remote host.
    [cmdFailed, cmdOut] = remoteConnection.runCommand(commandToRun);
catch err
    cmdFailed = true;
    cmdOut = err.message;
end
if cmdFailed
    dctSchedulerMessage(1, '%s: Failed to delete remote job storage location on cluster.  Reason:\n\t%s', currFilename, cmdOut);
end

end
