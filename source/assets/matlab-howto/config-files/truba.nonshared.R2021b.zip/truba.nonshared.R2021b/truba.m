c=parcluster;
c.AdditionalProperties.QueueName='hamsi';  
c.AdditionalProperties.WallTime='3-00:00:00';
c.AdditionalProperties.UseSshPort=22;     
c.NumThreads=28;
c.NumWorkers=1;
c.AdditionalProperties.Nodes=1
c.AdditionalProperties

%ek parametreler
%Baglanti ile ilgili paramerteler
%c.AdditionalProperties.AccountName='Truba_Slurm_Hesabi'
%c.AdditionalProperties.Username= 'Truba_kullanici_adi'
%c.AdditionalProperties.ClusterHost='172.16.7.1'
%c.AdditionalProperties.UseSshPort=22
%Eger her seferinde şifre yazmak istemiyorsanız kümeye baglantiyi parola yarine ssh anahtarınızla gerçekleştirebilirsiniz.
%c.AdditionalProperties.UseIdentityFile=1
%c.AdditionalProperties.IdentityFile='anahtar_dosyasinin_tam_yolu/id_rsa'
%c.AdditionalProperties.IdentityFileHasPassphrase: 0

%kuyruk ve is ile ilgili parametreler
%c.AdditionalProperties.QueueName='hamsi'
%c.NumThreads=28;
%c.AdditionalProperties.Nodes=1
%c.AdditionalProperties.WallTime= '3-00:00:00'
%c.AdditionalProperties.Reservation='Varsa_rezervasyon_adi'
%c.AdditionalProperties.EnableDebug= 0
%c.AdditionalProperties.RemoteJobStorageLocation='/truba/home/sefa/.matlab/3p_cluster_jobs/truba/Sefa-Macbook-Neu.local/R2021b/nonshared'
