c=parcluster;
c.NumThreads=40;
c.NumWorkers=1;
c.AdditionalProperties.QueueName='barbun';  
c.AdditionalProperties.Nodes=1
c.AdditionalProperties.WallTime='3-00:00:00';
c.AdditionalProperties.ClusterHost='172.16.6.11'
c.AdditionalProperties.UseSshPort=22;     
c.RequiresOnlineLicensing=true
c.saveProfile
c.AdditionalProperties

%ek parametreler
%Baglanti ile ilgili paramerteler
%c.AdditionalProperties.AccountName='Slurm Hesabinizin Adi'
%c.AdditionalProperties.Username= 'Arf kullanici adiniz'
%c.AdditionalProperties.ClusterHost='172.16.6.11'
%c.AdditionalProperties.UseSshPort=22
%Eger her seferinde şifre yazmak istemiyorsanız kümeye baglantiyi parola yarine ssh anahtarınızla gerçekleştirebilirsiniz.
%c.AdditionalProperties.UseIdentityFile=0
%c.AdditionalProperties.IdentityFile='anahtar_dosyasinin_tam_yolu/id_rsa'
%c.AdditionalProperties.IdentityFileHasPassphrase:0

%kuyruk ve is ile ilgili parametreler
%c.AdditionalProperties.QueueName='barbun'
%c.NumThreads=40;
%c.AdditionalProperties.Nodes=1
%c.AdditionalProperties.WallTime= '3-00:00:00'
%c.AdditionalProperties.Reservation='Varsa_rezervasyon_adi'
%c.AdditionalProperties.EnableDebug= 0
